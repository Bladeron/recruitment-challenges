function test() {
    console.log(1)
}

exports.test = test;