#Introduction 
See challenge instructions on the PDF.

#Getting Started
Install the dependencies by running `npm install`

#Build and Test
Run the tests using `npm test`

#Linting
If you want, you can lint your code using `npm run lint`

Good luck!